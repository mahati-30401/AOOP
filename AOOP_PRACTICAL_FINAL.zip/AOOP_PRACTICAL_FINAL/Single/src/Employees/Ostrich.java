package Employees;

public class Ostrich extends Bird {
	 public void fly() {
	       System.out.println("Ostriches can't fly.");
	    }

}
