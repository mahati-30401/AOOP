/**
 * 
 */
/**
 * 
 */
module Single {
}