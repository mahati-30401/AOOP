import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

// Class representing an Event
class Event {
    private String eventName;

    public Event(String eventName) {
        this.eventName = eventName;
    }

    public String getEventName() {
        return eventName;
    }

    @Override
    public int hashCode() {
        return eventName.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Event event = (Event) obj;
        return eventName.equals(event.eventName);
    }

    @Override
    public String toString() {
        return eventName;
    }
}

// Class for tracking event attendance
class AttendanceTracker {
    private Map<Event, Set<String>> eventAttendanceMap;

    public AttendanceTracker() {
        this.eventAttendanceMap = new HashMap<>();
    }

    // Add an event
    public void addEvent(String eventName) {
        Event event = new Event(eventName);
        eventAttendanceMap.putIfAbsent(event, new HashSet<>());
    }

    // Add an attendee to an event
    public void addAttendee(String eventName, String attendeeName) {
        Event event = new Event(eventName);
        if (!eventAttendanceMap.containsKey(event)) {
            System.out.println("Event does not exist!");
            return;
        }
        Set<String> attendees = eventAttendanceMap.get(event);
        if (attendees.add(attendeeName)) {
            System.out.println(attendeeName + " added to " + eventName);
        } else {
            System.out.println(attendeeName + " is already attending " + eventName);
        }
    }

    // List attendees for an event
    public void listAttendees(String eventName) {
        Event event = new Event(eventName);
        Set<String> attendees = eventAttendanceMap.get(event);
        if (attendees == null || attendees.isEmpty()) {
            System.out.println("No attendees for this event.");
        } else {
            System.out.println("Attendees for " + eventName + ": " + attendees);
        }
    }

    // Count attendees for an event
    public int countAttendees(String eventName) {
        Event event = new Event(eventName);
        Set<String> attendees = eventAttendanceMap.get(event);
        if (attendees == null) {
            return 0;
        }
        return attendees.size();
    }
}

// Main class to test the AttendanceTracker
public class Main {
    public static void main(String[] args) {
        AttendanceTracker tracker = new AttendanceTracker();

        // Adding events
        tracker.addEvent("Java Conference");
        tracker.addEvent("Python Workshop");

        // Adding attendees
        tracker.addAttendee("Java Conference", "Alice");
        tracker.addAttendee("Java Conference", "Bob");
        tracker.addAttendee("Python Workshop", "Charlie");
        tracker.addAttendee("Java Conference", "Alice"); // Duplicate attendee

        // Listing attendees
        tracker.listAttendees("Java Conference");
        tracker.listAttendees("Python Workshop");

        // Counting attendees
        System.out.println("Number of attendees in Java Conference: " + tracker.countAttendees("Java Conference"));
        System.out.println("Number of attendees in Python Workshop: " + tracker.countAttendees("Python Workshop"));
    }
}
