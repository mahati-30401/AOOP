package Game;

public interface Weapon {
void use();
}
