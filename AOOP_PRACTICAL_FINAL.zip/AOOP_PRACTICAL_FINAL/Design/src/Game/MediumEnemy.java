package Game;

public class MediumEnemy extends Enemy{
	public void attack() {
		System.out.println("Medium enemy attacks moderately");
	}

}
