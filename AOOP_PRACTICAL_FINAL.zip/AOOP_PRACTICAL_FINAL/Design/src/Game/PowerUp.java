package Game;

public interface PowerUp {
void activate();
}
