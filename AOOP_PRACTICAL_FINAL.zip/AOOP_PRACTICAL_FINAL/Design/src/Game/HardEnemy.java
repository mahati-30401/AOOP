package Game;

public class HardEnemy extends Enemy {
	public void attack() {
		System.out.println("Hard enemy attacks fiercely");
	}

}
