package TemplateDesignPattern;

public interface Observer {
	void update(String message);
}
