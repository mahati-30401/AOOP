package Music;

public interface MediaSource {
void play();
}
