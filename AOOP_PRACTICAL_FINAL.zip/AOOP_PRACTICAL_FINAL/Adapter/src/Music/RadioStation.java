package Music;

public class RadioStation {
public void playRadio() {
System.out.println("Playing music from radio station");
}
}
