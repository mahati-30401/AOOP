package Music;

public class LocalFile {

	public void playFile() {
		System.out.println("This is a playfile");
		
	}
 
}
