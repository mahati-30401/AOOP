package Music;

public class StandardPlayback implements PlaybackImplementation{
	public void play() {
		 System.out.println("Standard playback");	
	}

}
