package Bike;

public interface PaymentMethod {
void pay(double amount);
void payment(double d);
}

